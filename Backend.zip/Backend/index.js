//const connectToMongo=require('./db');
import connectToMongo from './db.js';
import express from 'express';
import {PORT} from "./config.js";  
//import {Book}   from './models/bookModel.js';
//import mongoose from'mongoose';
import bookRoute from './routes/bookRoute.js';
import cors from 'cors';
connectToMongo();
const app=express();
app.use(express.json());
//Middleware for handling CORS policy
//Option 1:Allow All Origins with Default of cors(*)


app.use(cors());
//Option 2:Allow custom Origin
/*app.use(  
    cors({
        origin:"http://localhost:3000",
        methods:['GET','POST','PUT','DELETE'],
        allowedHeaders:['Content-Type']
    })   
);*/    
//console.log("call coming in the backend");
     
app.get('/',(request,response)=>{             
   // console.log(request);
    return response.status(234).send('Welcome to MERN Tutorial');
});    
    
app.use('/books',bookRoute);
app.listen(PORT,()=>{
    console.log(`App is listening to port: ${PORT}`);
});           