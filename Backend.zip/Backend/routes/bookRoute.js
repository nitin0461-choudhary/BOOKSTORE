import express from 'express';
import {Book} from '../models/bookModel.js';
import mongoose from 'mongoose';
const router=express.Router();
///console.log("reached  in the backend change function first ");
router.post('/',async(request,response)=>{
    try{
       // console.log("reached  in the backend change function");
       // console.log("reached author:-",request.body.author);
       // console.log("reached title:-",request.body.title);
        
       // console.log("reached publishYear",request.body.publishYear);
        if(!request.body.title||!request.body.author||!request.body.publishYear){
            response.status(400).send({message:'Send all required fields title,author,publishYear'});
        }
        const newbook= new Book({
            title:request.body.title,
            author:request.body.author,
            publishYear:request.body.publishYear
        });
       // const book= await Book.create(newbook);
       await newbook.save();
       // const saved=await book.save();
      //  book.save();
     // return  
     //console.log('Book saved :',newbook);
        return response.status(201).json(newbook);
    }
    catch(error){

      ///  console.log("yesee u are theree ");
        console.log(error.message);
        response.status(500).send({error:error.message});
    }
});
//Route for Get All Books from database
router.get('/',async(request,response)=>{
    try{
        //console.log("reached ");
        //console.log("reached author:-",request.body.author);
        //console.log("reached title:-",request.body.title);
        
        //console.log("reached publishYear",request.body.publishYear);
       const books=await Book.find({});
        //const hj_book=Book;

     // return  
        return response.status(201).json(books);
    }
    catch(error){
        console.log(500);
        console.log(error.message);
        response.status(500).send({error:error.message});
    }
});
//get one book from the databse by its id
router.get('/:id',async(request,response)=>{
    try{
        const {id}=request.params;
        const book=await Book.findById(id);
        if(book){
            return response.status(201).json(book);
         }
        else{
            return response.status(404).json({message:'this book is not there'});
        }




        //console.log("reached ");
        //console.log("reached author:-",request.body.author);
        //console.log("reached title:-",request.body.title);
        
        //console.log("reached publishYear",request.body.publishYear);
      // const books=await Book.find({});
        //const hj_book=Book;

     // return  
       // return response.status(201).json(books);
    }
    catch(error){
        console.log(error.message);
        response.status(500).send({error:error.message});
    }
    

});
//Route for changing the book by getting its id 
router.put('/:id',async(request,response)=>{
    const {id}=request.params;
    const isValid=mongoose.Types.ObjectId.isValid(id);
    if(!isValid){
        return response.status(404).json({message:"This id is in valid"});
    }

     try{ 
        
        const bookfind= await Book.findById(id);
        if(!bookfind){
            return response.status(404).json({message:'This book is not there'});

        }
        const book=await Book.findByIdAndUpdate(id,request.body,{new:true,runValidators:true});
       // if(book){
            return response.status(200).json(book);
        /* }
        else{
            return response.status(404).json({message:'this book is not there'});
        }*/

     }
     catch(error){
        console.log(error.message);
        response.status(500).send({error:error.message});
     }g

});
//Route for deleting the book by getting its id 
router.delete('/:id',async(request,response)=>{
    const {id}=request.params;
    //const isValid=mongoose.Types.ObjectId.isValid(id);
   

     try{ 
        
        const bookfind= await Book.findByIdAndDelete(id);
        if(!bookfind){
            return response.status(404).json({message:'This book is not there'});

        }
       
       // if(book){ 
            return response.status(200).send("This Book is deleted successfully");
        /* }
        else{
            return response.status(404).json({message:'this book is not there'});
        }*/

     }
     catch(error){
        console.log(error.message);
        response.status(500).send({error:error.message});
     }

});
export default router;